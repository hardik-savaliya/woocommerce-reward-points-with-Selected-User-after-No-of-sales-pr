# WooCommerce Points and Rewards

Package | WC-Points-Rewards/Templates
---|:---
Author | WooThemes                         
Copyright | Copyright (c) 2013, WooThemes
License | http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
